import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

public class MongoDBExample {

    public static void main(String[] args) {
        // MongoDB URI (for local MongoDB server)
        MongoClient mongoClient = new MongoClient("localhost", 27017);

        // Access database and collection (will create if not exists)
        MongoDatabase database = mongoClient.getDatabase("myDatabase");
        MongoCollection<Document> collection = database.getCollection("myCollection");

        // CREATE: Insert a document
        Document doc = new Document("name", "John Doe").append("age", 30);
        collection.insertOne(doc);
        System.out.println("Document inserted");

        // READ: Query all documents
        for (Document d : collection.find()) {
            System.out.println(d.toJson());
        }

        // UPDATE: Update document
        collection.updateOne(new Document("name", "John Doe"), new Document("$set", new Document("age", 31)));
        System.out.println("Document updated");

        // DELETE: Delete document
        collection.deleteOne(new Document("name", "John Doe"));
        System.out.println("Document deleted");

        // Close connection
        mongoClient.close();
    }
}
